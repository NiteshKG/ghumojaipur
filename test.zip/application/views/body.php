<!DOCTYPE html>
<html>
<head>
  <title>Homepage</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  
</head>
<body>
  
 

  <div class="jumbotron">
    <h1 class="display-4">Ghumo jaipur</h1>
    <p class="lead">Let's explore the jaipur in unique way with us!!</p>
    <img src="<?php echo base_url().'/assets/images/amer.png' ?>" alt="">
    <a class="btn btn-primary btn-lg" href="<?= base_url().'index.php/home/learnmore/' ?>" role="button">Learn more</a>
  </div>

  
  

</body>
</html>
